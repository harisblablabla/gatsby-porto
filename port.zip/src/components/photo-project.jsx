import React from 'react'
import { graphql, Link, useStaticQuery } from "gatsby"
import Img from "gatsby-image"
import { Col, Row } from 'react-bootstrap'


export default function PhotoProject() {

    const pStyle = {
      color: '#B3B3B3'
    }

    const photoStyle = {
      borderRadius: '1em'
    }

    const data = useStaticQuery(
        graphql `
        query {
            project: allPortfolioCard(sort: {fields: link, order: DESC}) {
              edges {
                node {
                  id
                  title
                  desc
                  link
                  image {
                    childImageSharp {
                      fluid(maxWidth: 1000, maxHeight: 630) {
                        ...GatsbyImageSharpFluid
                      }
                    }
                  }
                }
              }
            }
          }
        `
    )
    return (
        data.project.edges.map( ({node}) => (
            <div key={node.id}>
              <Row className={'pt-4'}>
                <Col md={4}>
                  <Link to={node.link}>
                   <Img style={photoStyle} className={'mb-3'} fluid={node.image.childImageSharp.fluid} alt={node.alt} />
                  </Link>
                </Col>
                <Col md={8} className={'border-bottom pb-4'}>
                  <Link to={node.link}>
                    <h4>{node.title}</h4>
                  </Link>
                  <p style={pStyle}>{node.desc}</p>
                </Col>
              </Row>
            </div>
        ))
    )
        
        
    
}