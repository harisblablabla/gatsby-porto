import React from 'react'
import { graphql } from 'gatsby'
import Img from 'gatsby-image'
import { Col, Row, Container } from 'react-bootstrap'
import Navbar from './../components/navbar'


export default function Project1(props) {

    console.log(props)

    const arrData = props.data.project.nodes
    console.log()
    return(
        <div>
            <Container>
                <Navbar/>
                <Row className={`justify-content-center mt-5`}>
                    <Col md={8} className={`px-4`}>
                      <h3 className={'my-2'}>{arrData[0].title}</h3>           
                    </Col>
                </Row>
                <Row className={`justify-content-center`}>
                    <Col md={12} className={`px-4`}>
                      <Img className={'mt-5'} fluid={arrData[0].img[0].images.childImageSharp.fluid}/>    
                    </Col>
                    <Col md={8} className={`px-4`}>
                      <p className={'mt-5'}>{arrData[0].content[0].paragraph}</p>
                      <p className={'mt-3'}>{arrData[0].content[1].paragraph}</p>
                      <Img className={'mt-5'} fluid={arrData[0].img[1].images.childImageSharp.fluid}/> 
                      <p className={'mt-5'}>{arrData[0].content[2].paragraph}</p>
                      <p className={'mt-3'}>{arrData[0].content[3].paragraph}</p>

                      <h5 className={'mt-3'}>{arrData[1].title}</h5> 
                      <p className={'mt-3'}>{arrData[1].content[0].paragraph}</p>
                      <Img className={'mt-5'} fluid={arrData[1].img[0].images.childImageSharp.fluid}/> 
                      <Img className={''} fluid={arrData[1].img[1].images.childImageSharp.fluid}/> 

                      <h5 className={'mt-5'}>{arrData[2].title}</h5>
                      <p className={'mt-3'}>{arrData[2].content[0].paragraph}</p>
                      <h6 className={'mt-3'}>{arrData[2].subtitle[0].item}</h6>
                      <Img className={'mt-5'} fluid={arrData[2].img[0].images.childImageSharp.fluid}/> 
                      <h6 className={'mt-3'}>{arrData[2].subtitle[1].item}</h6>
                      <Img className={'mt-5'} fluid={arrData[2].img[1].images.childImageSharp.fluid}/> 
                      <h6 className={'mt-3'}>{arrData[2].subtitle[2].item}</h6>
                      <Img className={'mt-5'} fluid={arrData[2].img[2].images.childImageSharp.fluid}/> 

                      <h5 className={'mt-5'}>{arrData[3].title}</h5>
                      <p className={'mt-3'}>{arrData[3].content[0].paragraph}</p>
                      <Img className={'mt-5'} fluid={arrData[3].img[0].images.childImageSharp.fluid}/> 

                      <h5 className={'mt-5'}>{arrData[4].title}</h5>
                      <p className={'mt-3'}>{arrData[4].content[0].paragraph}</p>
                      <h6 className={'mt-3'}>{arrData[4].subtitle[0].item}</h6>
                      <Img className={'mt-5'} fluid={arrData[4].img[0].images.childImageSharp.fluid}/> 





 
                    </Col>
                </Row>
            </Container>
        </div>
    )
}

export const query = graphql`
    query {
        project: allProject1Yaml {
          nodes {
            title
            subtitle {
              item
            }
            content {
              paragraph
            }
            img {
              images {
                childImageSharp {
                  fluid {
                    ...GatsbyImageSharpFluid
                  }
                }
              }
            }
          }
        }
    }
`