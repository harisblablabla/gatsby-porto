import React from 'react'
import { Col, Row } from 'react-bootstrap'
import Container from "react-bootstrap/Container"
import Navbar from "../components/navbar"
import PhotoProject from '../components/photo-project'



export default function Project({data}) {


    return(
        <div>
            <Container>
                <Navbar/>
                <Row className={`justify-content-center mt-5`}>
                    <Col md={10} className={`px-4`}>
                      
                    <PhotoProject/>
                      
                    </Col>
                </Row>
            </Container>
        </div>
    ) 
}

// export const query = graphql`
//   query {
//     project: allProjectYaml {
//       edges {
//         node {
//           id
//           image {
//             childImageSharp {
//               fluid {
//                 ...GatsbyImageSharpFluid
//               }
//             }
//           }
//         }
//       }
//     }
//   }
// `