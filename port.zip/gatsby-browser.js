import './src/styles/global.css';
import 'bootstrap/dist/css/bootstrap.min.css';